return {
    check       = require "roles.check",
    withindlg   = require "roles.withindlg",
    relay       = require "roles.relay",
    nathandle   = require "roles.nathandle",
    registrar   = require "roles.registrar",
    auth        = require "roles.auth",
    locate      = require "roles.locate",
    http_server = require "roles.http_server"
}