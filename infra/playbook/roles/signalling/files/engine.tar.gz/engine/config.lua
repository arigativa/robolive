return {
    locationStorage = "location",
    allowedUnames = {
        robohuman = true,
        robomachine = true
    }

}