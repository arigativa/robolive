return {
    websocket = {
        port = 4443,
    },
    locationStorage = "location",
    allowedUnames = {
        robohuman = true,
        robomachine = true
    }

}