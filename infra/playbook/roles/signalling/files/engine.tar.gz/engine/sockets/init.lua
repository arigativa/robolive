return {
    websocket = require "sockets.websocket"
}